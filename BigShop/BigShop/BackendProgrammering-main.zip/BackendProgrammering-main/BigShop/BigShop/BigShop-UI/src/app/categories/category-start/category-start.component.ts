import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-start',
  templateUrl: './category-start.component.html',
  styleUrls: ['./category-start.component.css']
})
export class CategoryStartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
