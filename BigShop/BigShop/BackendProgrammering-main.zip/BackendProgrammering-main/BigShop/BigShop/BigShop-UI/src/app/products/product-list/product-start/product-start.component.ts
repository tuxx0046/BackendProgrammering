import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-start',
  templateUrl: './product-start.component.html',
  styleUrls: ['./product-start.component.css']
})
export class ProductStartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
