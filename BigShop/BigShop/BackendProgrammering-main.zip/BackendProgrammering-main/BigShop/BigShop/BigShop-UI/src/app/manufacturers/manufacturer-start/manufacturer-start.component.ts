import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manufacturer-start',
  templateUrl: './manufacturer-start.component.html',
  styleUrls: ['./manufacturer-start.component.css']
})
export class ManufacturerStartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
