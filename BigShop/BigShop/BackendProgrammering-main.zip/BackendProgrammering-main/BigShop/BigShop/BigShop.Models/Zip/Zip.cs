﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigShop.Models.Zip
{
    public class Zip : ZipCreate
    {
        public int Id { get; set; }
    }
}
