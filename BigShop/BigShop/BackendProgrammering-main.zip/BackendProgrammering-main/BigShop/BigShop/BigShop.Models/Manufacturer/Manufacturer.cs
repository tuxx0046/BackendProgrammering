﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigShop.Models.Manufacturer
{
    public class Manufacturer : ManufacturerCreate
    {
        public int Id { get; set; }
    }
}
