﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigShop.Models.Department
{
    public class Department : DepartmentCreate
    {
        public int Id { get; set; }
    }
}
