﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigShop.Models.PaymentMethod
{
    public class PaymentMethod : PaymentMethodCreate
    {
        public int Id { get; set; }
    }
}
