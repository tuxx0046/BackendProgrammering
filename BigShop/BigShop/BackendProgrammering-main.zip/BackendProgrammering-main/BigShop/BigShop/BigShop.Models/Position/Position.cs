﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigShop.Models.Position
{
    public class Position : PositionCreate
    {
        public int Id { get; set; }
    }
}
