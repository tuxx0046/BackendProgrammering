﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigShop.Models.Customer
{
    public class Customer : CustomerCreate
    {
        public int Id { get; set; }
    }
}